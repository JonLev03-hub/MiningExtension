License: (Creative Commons Zero, CC0)
http://creativecommons.org/publicdomain/zero/1.0/

This content is free to use in personal, educational and commercial projects.
No attribution required, but if you wish, please link to my itch.io (https://vailor1.itch.io/) or my twitter (https://twitter.com/Vailor11)

Palette: NES